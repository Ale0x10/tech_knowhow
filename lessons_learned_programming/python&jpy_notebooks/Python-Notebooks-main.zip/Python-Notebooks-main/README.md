# Python3_Jupyter_Notebook
*This Jupyter Notebook has been developed based on "A Beginner's Python Tutorial" by Steven Thurlow and Aaditya Maheshwari. The __[original material](https://github.com/stoive/pythontutorial)__ has been ported to Python 3.*

*This work is licensed under the Creative Commons Attribution 2.5 Australia License. To view a copy of this license, visit http://creativecommons.org/licenses/by/2.5/au/ or send a letter to Creative Commons, 444 Castro Street, Suite 900, Mountain View, California, 94041, USA.*
